Auteur : ZarKyo

Catégorie : Cryptographie

---

# Tout droit vers le point

## Ennoncé

Un espion americain infiltré en Russie vous a contacté en morse pour vous transmettre 2 messages. A vous des les déchiffrer.
Auparavant, il vous a transmis une suite de charactère incompréhensible et une grille mais incomplète, à quoi peut-elle bien servir ?

- Message chiffré : GGGGXGVGAFFAFFDDDDFDFAAGVGDAVDFXDXADVXFDVVFDFFVDGGGGFVAAAFDGAAGFFFFAFAAXVGAVVVDDXDXGAVFDAAADGVGXAVXGAAXFGVGVVDVAXFXVAVAAFXVVXX
- Grille incomplète : L5BWRD.C7UAFH3.XE6O2S.1VIN4G0.TQ9Z8.
- 2 audios
