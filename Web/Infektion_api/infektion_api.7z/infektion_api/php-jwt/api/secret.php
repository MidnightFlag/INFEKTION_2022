<?php
include_once './config/database.php';
require "../vendor/autoload.php";
use \Firebase\JWT\JWT;
use Firebase\JWT\Key;

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$public_keyfile = 'ay01fmQ0PVlkKkZ3VWpqOHltdEU9NS5YY2cmZj9i';
$public_key = strval($public_keyfile);
$jwt = null;
$databaseService = new DatabaseService();
$conn = $databaseService->getConnection();

$data = json_decode(file_get_contents("php://input"));
$authHeader = $_SERVER['HTTP_AUTHORIZATION'];
$arr = explode(" ", $authHeader);


    echo json_encode(array(
        "message" => $arr[1]
    ));
    
    $jwt = $arr[1];
    
    if($jwt){
    
        try {
    
            $decoded = JWT::decode($jwt, new Key($public_key, 'HS256'));
            
            // Access is granted. Add code of the operation here 
            if($decoded->data->role !== "admin"){
                echo json_encode(array(
                    "message" => "Stop, you have to be admin to access to this secret page",
                ));
                
            }else{
                echo json_encode(array(
                    "Flag" => "MCTF{SSRF_t0_D1scl0se_jwt_K3y}",
                ));
            }
    
        }catch (Exception $e){
    
        http_response_code(401);
    
        echo json_encode(array(
            "message" => "Access denied.",
            "error" => $e->getMessage()
        ));
    }
    
    }
    ?>
