<?php
include_once "./config/database.php";

header("Access-Control-Allow-Origin: * ");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$firstName = '';
$lastName = '';
$email = '';
$password = '';
$url_profile_img = '';
$conn = null;

$databaseService = new DatabaseService();
$conn = $databaseService->getConnection();

$data = json_decode(file_get_contents("php://input"));

$firstName = $data->first_name;
$lastName = $data->last_name;
$email = $data->email;
$password = $data->password;
$url_profile_img = $data->url_profile_img;

$table_name = 'Users';

$query = "INSERT INTO " . $table_name . "
                SET first_name = :firstname,
                    last_name = :lastname,
                    email = :email,
                    password = :password";

$stmt = $conn->prepare($query);

$stmt->bindParam(':firstname', $firstName);
$stmt->bindParam(':lastname', $lastName);
$stmt->bindParam(':email', $email);

$password_hash = password_hash($password, PASSWORD_BCRYPT);

$stmt->bindParam(':password', $password_hash);

if (isset($url_profile_img) && !empty($url_profile_img)){
    $interdits = array(
        '<',
        '>',
        '%',
        '\.\.', 
        '^/+.*',
        'file:///',
        'data://',
        'zip://',
        'ftp://',
        'phar://',
        'zlib://',
        'glob://',
        'expect://',
        'login.php',
	    'secret.php',
        'php://filter/convert.base64-encode/resource=key/pubkey.key',
    );
    $regexp = implode('|', $interdits);
    if (preg_match('#' . $regexp . '#i', $url_profile_img) !== 0){
        echo "stop try to hack me";
    }else{

        http_response_code(200);
        $url = $url_profile_img;
        $res = file_get_contents($url, true);
        echo json_encode($res);
    }

}

if($stmt->execute()){

    http_response_code(200);
    echo json_encode(array(
        "message" => "User was successfully registered."
    ));
}
else{
    http_response_code(400);

    echo json_encode(array("message" => "Unable to register the user
    send this following param: first_name, last_name,email, url_profile_img, password"));
}

/*TODO: 
JWT Key in /etc/key/pubkey.key*/
?>