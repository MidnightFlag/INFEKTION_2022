<?php
class DatabaseService{

    private $db_host = "mysql";
    private $db_name = "db";
    private $db_user = "admin";
    private $db_password = "M1dnight_sql_p4ssw0rd";
    private $connection;

    public function getConnection(){

        $this->connection = null;

        try{
            $this->connection = new PDO("mysql:host=" . $this->db_host . ";dbname=" . $this->db_name, $this->db_user, $this->db_password);
        }catch(PDOException $exception){
            echo "Connection failed: " . $exception->getMessage();
        }

        return $this->connection;
    }
}
?>