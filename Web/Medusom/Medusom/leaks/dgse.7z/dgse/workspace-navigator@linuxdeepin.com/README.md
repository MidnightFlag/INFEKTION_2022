Allow selection of workspaces with up and down arrow keys in overlay mode

Based on the windowNavigator extension - http://git.gnome.org/gnome-shell-extensions
