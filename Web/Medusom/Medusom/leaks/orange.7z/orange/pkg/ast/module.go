package ast

type Module struct {
	Name string
	AST  []Node
}
