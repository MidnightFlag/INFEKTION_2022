package token

type Associativity int8

const (
	LeftAssociativity Associativity = iota
	RightAssociativity
)
