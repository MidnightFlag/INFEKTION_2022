import { NgModule } from '@angular/core';
import { TrophyComponent } from './trophy/trophy';
@NgModule({
  declarations: [
    TrophyComponent
  ],
  imports: [],
  exports: [
    TrophyComponent
  ]
})
export class ComponentsModule {}
