import { Component } from '@angular/core';

@Component({
  selector: 'trophy',
  templateUrl: 'trophy.html'
})
export class TrophyComponent {

  constructor() {}

}
